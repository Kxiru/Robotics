import java.util.ArrayList;

import lejos.hardware.Sound;
import lejos.robotics.navigation.Pose;
import lejos.robotics.subsumption.Behavior;

//this class is the behaviour to draw the map
public class Map implements Behavior {
	private ArrayList<Pose> poseList;
	private ArrayList<String[]> blockList;
	Map(ArrayList<Pose> l, ArrayList<String[]> b) {
		poseList = l;
		blockList = b;
	}
	
	public void action() {
		//draw fucking map
		Sound.beepSequence();
		//cast poselist to string[]
		String[] poseArray = poseList.toArray(new String[poseList.size()]);
		//cast blocklist to string[]
		String[] blockArray = blockList.toArray(new String[blockList.size()]);
		//combine them
		String[] completeList = mergeArrays(poseArray, blockArray);
		//build the map
		BuildMap.main(completeList);
	}
	
	public void suppress() {}
		
	public boolean takeControl() { //behaviour kicks in when all 6 objects have been scanned
		return (poseList.size() == 6);
	}
	
	 public static String[] mergeArrays(String[] first, String[] second) { //method to merge the two string arrays for processing
		 String result = "";
		 for(String i : first){
			 result += i + ";";
		 }
		 for(String i : second){
			 result += i + ";";
		 }
		 return result.split(";");
	 }
}