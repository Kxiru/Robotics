//quick class i (kaelin) made to store and handle the rotation of the robot, saves a lot of time with saving
public class Booler {
	private boolean state; //current state of rotation
	
	public Booler(boolean state) { //constructor
		this.state = state;
	}
	
	public boolean getBoolean() { //returns boolean
		return state;
	}
	
	public void inverse() { //inverts boolean
		state = !state;
	}
}
