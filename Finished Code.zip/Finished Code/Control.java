import java.util.ArrayList;

import lejos.hardware.Button;
import lejos.hardware.motor.BaseRegulatedMotor;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3GyroSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;
import lejos.robotics.chassis.Chassis;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;
import lejos.robotics.localization.OdometryPoseProvider;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.Pose;
import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class Control {
	/*
	 * This is the main class in which our behaviours are driven and all of our objects are created
	 */
	final static float wheelDiameter = 55.8f; //accurately measured wheel diameter
	final static float axleLength = 114.5f; //accurately measured axle length
	public static void main(String[] args) {
		BaseRegulatedMotor mLeft = new EV3LargeRegulatedMotor(MotorPort.A);
		BaseRegulatedMotor mRight = new EV3LargeRegulatedMotor(MotorPort.B);
		//creating the wheels and chassis
		Wheel wLeft = WheeledChassis.modelWheel(mLeft, wheelDiameter).offset(-axleLength/2);
		Wheel wRight = WheeledChassis.modelWheel(mRight, wheelDiameter).offset(axleLength/2);
		Chassis chassis = new WheeledChassis(new Wheel[] {wRight, wLeft}, WheeledChassis.TYPE_DIFFERENTIAL);
		//creating the movepilot and setting appropriate speeds
		MovePilot pilot = new MovePilot(chassis);
		pilot.setLinearSpeed(100);
		pilot.setAngularSpeed(25); //rotational speed is slow to avoid rotational errors
		//creating ultrasonic sensor
		EV3UltrasonicSensor distanceSensor = new EV3UltrasonicSensor(SensorPort.S2);
		SampleProvider distanceProvider = distanceSensor.getDistanceMode();
		//creating coloursensor
		EV3ColorSensor colorSensor = new EV3ColorSensor(SensorPort.S1);
		SampleProvider colorProvider = colorSensor.getRedMode();
		//creating gyrosensor
		EV3GyroSensor gyroSensor = new EV3GyroSensor(SensorPort.S4);
		SampleProvider angleProvider = gyroSensor.getAngleMode();
		//creating poseprovider and poselist for
		ArrayList<Pose> poses = new ArrayList<Pose>();
		ArrayList<String[]> blocks = new ArrayList<String[]>();
		//
		PoseProvider position = new OdometryPoseProvider(pilot); 
		//creating QR code scanner object (which we created ourselves)
		QRScanner codeScanner = new QRScanner();
		//to manage direction:
		Booler direction = new Booler(true); //this is used to control the turns of the robot so it traverses across the map properly
		//creating behaviours and passing all necessary objects to them
		Behavior trundle = new Trundle(pilot);
		Behavior scan = new Scan(pilot, distanceProvider, angleProvider, gyroSensor, position, codeScanner, direction, poses, blocks);
		Behavior spin = new Spin(pilot, colorProvider, angleProvider, gyroSensor, position, direction);
		Behavior drawmap = new Map(poses, blocks);
		//and finally
		Arbitrator ab = new Arbitrator(new Behavior[] {trundle, spin, scan, drawmap}); //arbitrator to handle them
		Button.ENTER.waitForPressAndRelease(); //wait until ready
		ab.go();//GO!
		//and to finally close all those sensors
		Button.ENTER.waitForPressAndRelease();
		colorSensor.close();
		distanceSensor.close();
		gyroSensor.close();
	}
}
