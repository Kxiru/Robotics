import java.io.IOException;
import java.util.ArrayList;

import lejos.hardware.Sound;
import lejos.hardware.lcd.LCD;
import lejos.hardware.sensor.EV3GyroSensor;
import lejos.robotics.SampleProvider;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.Pose;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

//this is the class where the robot will see an object, scan it and add it to the list of objects and continue on with its day
public class Scan implements Behavior { //lots of params as lots of objects will be used in this class
	private MovePilot pilot;
	private SampleProvider sensor, angleProvider;
	private EV3GyroSensor angleSensor;
	private PoseProvider poseProvider;
	private QRScanner codeScanner;
	private Booler currentDirection;
	private ArrayList<Pose> poseList;
	private ArrayList<String[]> blockList;
	
	float[] distances = new float[1];
	float[] angles = new float[1];
	
	Scan(MovePilot p, SampleProvider s, SampleProvider a, EV3GyroSensor g, PoseProvider pp, QRScanner sc, Booler direction, ArrayList<Pose> l, ArrayList<String[]> b) { //constructor taking huge number of arguments
		pilot = p;
		sensor = s;
		angleProvider = a;
		angleSensor = g;
		poseProvider = pp;
		codeScanner = sc;
		currentDirection = direction;
		poseList = l;
		blockList = b;
	}
	
	public void action() {
		pilot.stop();
		Sound.beepSequenceUp();
		//scan qr code and add object, check for duplicate
		//jot pose
		String[] block = null;
		try {
			block = codeScanner.scanQR();
		} catch (IOException e) {
			// IOException
			e.printStackTrace();
		}
		Pose newPose = poseProvider.getPose();
		//alter location of pose relative to location of block in front of robot due to 20mm buffer zone
		if (currentDirection.getBoolean()==true) {
			newPose.setLocation(newPose.getX()+20, newPose.getY());
		} else {
			newPose.setLocation(newPose.getX()-20, newPose.getY());
		}
		//alter pose to relative block
		poseList.add(newPose);//add pose to poseList of that block
		blockList.add(block); //add block info to plot on map
		currentDirection.inverse(); //inverts direction as robot gonna be turning around
		//turn around
		turn(180, newPose);
		//carry on
		LCD.clear();
		LCD.drawString(newPose.toString(), 0, 2); //just for some output whils the robot runs
	}
	
	//since action returns immediately probably never called
	public void suppress() {}
	
	public boolean takeControl() { //takes control when the ultrasonic sensor gets VERY close to a lego block
		sensor.fetchSample(distances, 0);
		return (distances[0] <=0.2);
	}
	
	public void turn(float targetAngle, Pose currentPose) { //turn method which uses gyroscopic sensor to correct rotation :)
		Delay.msDelay(1000);
		angleSensor.reset();
		//get current pose
		currentPose.setHeading(currentPose.getHeading()-targetAngle);
		//rotate
		pilot.rotate(targetAngle);
		//now to correct the rotation
		Delay.msDelay(1000);
		angleProvider.fetchSample(angles, 0);
		while (-targetAngle != angles[0]) { //repeat correction until angle is perfect
			LCD.drawString(Float.toString(angles[0]), 2, 4);
			pilot.rotate(targetAngle-(-angles[0]));
			Delay.msDelay(1000);
			angleProvider.fetchSample(angles, 0);
		}
		poseProvider.setPose(currentPose); //finally set the pose
	}
}
