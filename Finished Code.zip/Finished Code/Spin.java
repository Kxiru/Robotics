import lejos.hardware.lcd.LCD;
import lejos.hardware.sensor.EV3GyroSensor;
import lejos.robotics.SampleProvider;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.Pose;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

//this is class in which the robot will reach a line, turn and traverse and then re-enter the boundary
public class Spin implements Behavior {
	private MovePilot pilot;
	private SampleProvider sensor, angle;
	private EV3GyroSensor angleSensor;
	private PoseProvider position;
	float[] colors = new float[1];
	float[] angles = new float[1];
	Booler currentRotation;
	Spin(MovePilot p, SampleProvider c, SampleProvider d, EV3GyroSensor s, PoseProvider o, Booler direction) { //constructor method
		pilot = p;
		sensor = c;
		angle = d;
		angleSensor = s;
		position = o;
		currentRotation = direction;
	}
	
	public void action() { 
		pilot.stop();
		pilot.travel(-25); //so robot is on the line when traversing, reverse a little
		//
		Pose currentPose = position.getPose();
		if (currentRotation.getBoolean() == true) { //value of currentrotation depends on which way it rotates so map is traversed
			currentPose.setLocation(1800, currentPose.getY());
			turn(-90, currentPose);
			pilot.travel(150);
			currentPose = position.getPose();
			turn(-90, currentPose);
		} else {
			currentPose.setLocation(0, currentPose.getY());
			turn(90, currentPose);
			pilot.travel(150);
			currentPose = position.getPose();
			turn(90, currentPose);
		}
		pilot.travel(100); //travel forward a bit so off the line
		currentRotation.inverse(); //invert currentrotation
	}
	
	public void suppress() {}
		
	public boolean takeControl() { //behaviour kicks in when coloursensor sees black line boundary
		sensor.fetchSample(colors, 0);
		return (colors[0] <0.25);
	}
	
	public void turn(float targetAngle, Pose currentPose) {
		Delay.msDelay(1000);
		angleSensor.reset();
		//get current pose
		currentPose.setHeading(currentPose.getHeading()-targetAngle);
		//rotate
		pilot.rotate(targetAngle);
		//now to correct the rotation
		Delay.msDelay(1000);
		angle.fetchSample(angles, 0);
		while (-targetAngle != angles[0]) {
			LCD.drawString(Float.toString(angles[0]), 2, 4);
			pilot.rotate(targetAngle-(-angles[0]));
			//finally set the pose
			Delay.msDelay(1000);
			angle.fetchSample(angles, 0);
		}
		position.setPose(currentPose);
	}
}